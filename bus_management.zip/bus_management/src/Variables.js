export const variables={
    API_URL: "https://localhost:7217/api/",
    
}